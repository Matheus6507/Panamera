﻿using System;
using BLL;

namespace Panamera
{
    class Program
    {
        static void Main(string[] args)
        {
            ArquivoBLL bll = new ArquivoBLL();
            MailBLL mail = new MailBLL();

            bll.LoadFiles();

            //Envia um email caso tenha exceções
            /*if (bll.PrintException() != "")
            {
                mail.SendMail(bll.PrintException());
            }
            else { Console.Write("Fim"); }*/
            Console.WriteLine(bll.PrintException());
            Console.Write("Fim");
            Console.ReadKey();
        }
    }
}