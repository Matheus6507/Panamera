﻿using System;
using System.Configuration;
using DTO;
using System.IO;

namespace BLL
{
    class ArquivoBLL
    {
        readonly string dropbox = ConfigurationManager.AppSettings["Origem_BK_BD"];
        readonly string hd_secundario = ConfigurationManager.AppSettings["Destino_BK_BD"];
        string exception = "";

        //Carrega os arquivos e preenche o vetor files
        public void LoadFiles()
        {
            ArquivoDTO arq = new ArquivoDTO();
            string[] files = Directory.GetFiles(dropbox);

            foreach (string file in files)
            {
                arq.Nome = Path.GetFileNameWithoutExtension(file);
                string[] names = arq.Nome.Split('_');
                string[] extension = Path.GetFileName(file).Split('.');

                arq.Sistema = names[0];
                arq.Extensao = extension[1];

                if (arq.Sistema.ToLower() != "sienge")
                {
                    arq.Data = new DateTime(int.Parse(names[2]), int.Parse(names[3]), int.Parse(names[4]));
                }
                else
                {
                    arq.Data = new DateTime(int.Parse(names[3]), int.Parse(names[1]), int.Parse(names[2]));
                }

                CalcDays(arq);
            }
        }

        //Calcula os dias passados da data de criação do arquivo até a data atual do computador
        public void CalcDays(ArquivoDTO arq)
        {
            TimeSpan date = DateTime.Now - arq.Data;
            int Diferenca = date.Days;

            if (Diferenca <= 7)
            {
                Console.WriteLine("Arquivo criado a menos de uma semana!");
            }
            else if (Diferenca <= 30 && Diferenca > 7)
            {
                try
                {
                    Is30Days(arq);
                }

                //Se o arquivo estiver já existir no destino exibe uma mensagem na tela e pula para o próximo
                catch (Exception ex)
                {
                    if (File.Exists(hd_secundario.ToString() + arq.Nome.ToString() + "." + arq.Extensao.ToString()))
                    {
                        Console.WriteLine("Arquivo já existente no hd_secundario");
                    }
                    //Armazena a exceção em uma variável
                    else { exception += ex.ToString() + " @ "; }
                }
                finally { }
            }
            else if (Diferenca > 30 && Diferenca <= 90)
            {
                try
                {
                    Is90DaysOrLess(arq);
                }
                //Se o arquivo estiver já existir no destino exibe uma mensagem na tela e pula para o próximo
                catch (Exception ex)
                {
                    if (File.Exists(hd_secundario.ToString() + arq.Nome.ToString() + "." + arq.Extensao.ToString()))
                    {
                        Console.WriteLine("Arquivo já existente no hd_secundario");
                    }
                    //Armazena a exceção em uma variável
                    else { exception += ex.ToString() + " @ "; }
                }
                finally { }
            }
            else if (Diferenca > 90 && Diferenca < 365)
            {
                try
                {
                    Is90DaysOrMore(arq);
                }
                //Se o arquivo estiver já existir no destino exibe uma mensagem na tela e pula para o próximo
                catch (Exception ex)
                {
                    if (File.Exists(hd_secundario.ToString() + arq.Nome.ToString() + "." + arq.Extensao.ToString()))
                    {
                        Console.WriteLine("Arquivo já existente no hd_secundario");
                    }
                    //Armazena a exceção em uma variável
                    else { exception += ex.ToString() + " @ "; }
                }
                finally { }

            }
            else
            {
                try
                {
                    Is1YearOrMore(arq);
                }
                //Se o arquivo estiver já existir no destino exibe uma mensagem na tela e pula para o próximo
                catch (Exception ex)
                {
                    if (File.Exists(hd_secundario.ToString() + arq.Nome.ToString() + "." + arq.Extensao.ToString()))
                    {
                        Console.WriteLine("Arquivo já existente no hd_secundario");
                    }
                    //Armazena a exceção em uma variável
                    else { exception += ex.ToString() + " @ "; }
                }
                finally { }
            }
        }

        //Ações para arquivos com data superior a 1 semana e inferior a 30 dias
        private void Is30Days(ArquivoDTO arq)
        {
            //Verifica se o arquivo é do primeiro ou ultima dia do ano
            if (IsFirstOrLastDayOfYear(arq) == false)
            {
                //Move os arquivos de sienge e maestro que não sejam de domingo ou de quarta-feira para o HD Secundário
                if (arq.Data.DayOfWeek != 0 && (int)arq.Data.DayOfWeek != 3 && arq.Sistema.ToLower() != "lotesbrasil")
                {
                    File.Move(dropbox + arq.Nome + "." + arq.Extensao.ToString(), hd_secundario + arq.Nome + "." + arq.Extensao.ToString());
                    Console.WriteLine(arq.Nome);
                }
                //Mantém todos os arquivos do materre do dia 15 no DROPBOX e elimina o resto
                else if (arq.Data.Day != 15 && arq.Sistema.ToLower() == "lotesbrasil")
                {
                    File.Move(dropbox + arq.Nome + "." + arq.Extensao.ToString(), @"C:\Users\VPA TI\Desktop\Robo Backup\Lixo\" + arq.Nome + "." + arq.Extensao.ToString());
                    Console.WriteLine(arq.Nome);
                }
            }
        }

        //Ações para arquivos com data superior a 30 dias e inferior a 90
        private void Is90DaysOrLess(ArquivoDTO arq)
        {
            //Verifica se o arquivo é do primeiro ou ultima dia do ano
            if (IsFirstOrLastDayOfYear(arq) == false)
            {
                //Move todos os arquivos de sienge e maestro que não sejam do dia 1 ou do dia 15 para o HD Secundário
                if (arq.Data.Day != 1 && arq.Data.Day != 15 && arq.Sistema.ToLower() != "lotesbrasil")
                {
                    File.Move(dropbox + arq.Nome + "." + arq.Extensao.ToString(), hd_secundario + arq.Nome + "." + arq.Extensao.ToString());
                    Console.WriteLine(arq.Nome);
                }
                //Mantém todos os arquivos do materre do dia 15 no DROPBOX e elimina o resto
                else if (arq.Data.Day != 15 && arq.Sistema.ToLower() == "lotesbrasil")
                {
                    File.Move(dropbox + arq.Nome + "." + arq.Extensao.ToString(), @"C:\Users\VPA TI\Desktop\Robo Backup\Lixo\" + arq.Nome + "." + arq.Extensao.ToString());
                    Console.WriteLine(arq.Nome);
                }
            }
        }

        //Ações para arquivos com data superior a 90 dias e inferior a 1 ano
        private void Is90DaysOrMore(ArquivoDTO arq)
        {
            //Verifica se o arquivo é do primeiro ou ultima dia do ano
            if (IsFirstOrLastDayOfYear(arq) == false)
            {
                //Mantém o arquivo de sienge ou maestro com data do dia 15 no DROPBOX
                if (arq.Data.Day != 15 && arq.Sistema.ToLower() != "lotesbrasil")
                {
                    //Move o arquivo de sienge ou maestro com data do dia 01 para o HD Secundário
                    if (arq.Data.Day == 1)
                    {
                        File.Move(dropbox + arq.Nome + "." + arq.Extensao.ToString(), hd_secundario + arq.Nome + "." + arq.Extensao.ToString());
                        Console.WriteLine(arq.Nome);
                    }
                    //Elimina todos os arquivos de sienge e materre que tenham mais de 90 dias e não sejam do dia 01 e dia 15
                    else
                    {
                        File.Move(dropbox + arq.Nome + "." + arq.Extensao.ToString(), @"C:\Users\VPA TI\Desktop\Robo Backup\Lixo\" + arq.Nome + "." + arq.Extensao.ToString());
                        Console.WriteLine(arq.Nome);
                    }
                }
                //Copia os arquivos de sienge e maestro com data do dia 15 para o HD Secundário
                else if (arq.Data.Day == 15 && arq.Sistema.ToLower() != "lotesbrasil")
                {
                    File.Copy(dropbox + arq.Nome + "." + arq.Extensao.ToString(), hd_secundario + arq.Nome + "." + arq.Extensao.ToString());
                    Console.WriteLine(arq.Nome);
                }

                //Move os arquivos do Materre com data do dia 15 para o HD Secundário
                else if (arq.Data.Day != 15 && arq.Sistema.ToLower() == "lotesbrasil")
                {
                    File.Move(dropbox + arq.Nome + "." + arq.Extensao.ToString(), @"C:\Users\VPA TI\Desktop\Robo Backup\Lixo\" + arq.Nome + "." + arq.Extensao.ToString());
                    Console.WriteLine(arq.Nome);
                }
                //Elimina todos os arquivos do materre que tenham mais de 90 dias e não seja do dia 15
                else if (arq.Data.Day == 15 && arq.Sistema.ToLower() == "lotesbrasil")
                {
                    File.Move(dropbox + arq.Nome + "." + arq.Extensao.ToString(), hd_secundario + arq.Nome + "." + arq.Extensao.ToString());
                    Console.WriteLine(arq.Nome);
                }
            }
        }

        //Ações para arquivos com data superior a 1 ano
        private void Is1YearOrMore(ArquivoDTO arq)
        {
            //Verifica se o arquivo é do primeiro ou ultima dia do ano
            if (IsFirstOrLastDayOfYear(arq) == false)
            {
                //Move os arquivos com data do dia 15 para o HD Secundário
                if (arq.Data.Day == 15)
                {
                    File.Move(dropbox + arq.Nome + "." + arq.Extensao.ToString(), hd_secundario + arq.Nome + "." + arq.Extensao.ToString());
                    Console.WriteLine(arq.Nome);
                }
                //Elimina todos os arquivos que não sejam do dia 15 e não sejam do primeiro ou ultimo dia do ano
                else
                {
                    File.Move(dropbox + arq.Nome + "." + arq.Extensao.ToString(), @"C:\Users\VPA TI\Desktop\Robo Backup\Lixo\" + arq.Nome + "." + arq.Extensao.ToString());
                    Console.WriteLine(arq.Nome);
                }
            }
        }

        //Verifica se o arquivo é do primeiro ou ultimo dia do ano
        private bool IsFirstOrLastDayOfYear(ArquivoDTO arq)
        {
            if (arq.Data.DayOfYear != 1 && arq.Data.DayOfYear != 365)
            {
                return false;
            }
            else return true;
        }

        //Retorna a variável de exceção
        public string PrintException()
        {
            return exception;
        }
    }
}
