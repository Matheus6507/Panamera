﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;

namespace BLL
{
    class MailBLL
    {
        MailMessage mail = new MailMessage();

        public void SendMail(string subject)
        {
            mail.From = new MailAddress("adm@grupovpa.com.br");
            mail.To.Add("matheus.afonsos@grupovpa.com.br");
            mail.To.Add("arthur@grupovpa.com.br");
            mail.Subject = "Exception Panamera";
            mail.Body = subject;

            SmtpClient client = new SmtpClient
            {
                Host = "smtp.gmail.com",
                Port = 587,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                EnableSsl = true,
                Credentials = new NetworkCredential("adm@grupovpa.com.br", "ekipamento.1")
            };
            client.Send(mail);

            /* em caso de anexos
            mail.Attachments.Add(new Attachment(@"C:\teste.txt"));*/
        }
    }
}
